const http = require('http')

let server = http.createServer((req, res) => {
    res.writeHead(200, {'Content-Type': 'text/html'});

    let content = `
    <html>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    </head>
    <body>
    <h1>如何引入本地js</h1>
    <script src="./main.js"></script>
    </body>
    </html>
    `
    res.write(content);
    
    res.end();
})

server.listen(8090,() => {
    console.log('Node.js server is ready, listening on http://localhost:8090');
})
