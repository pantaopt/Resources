import React from "react";
import ReactDOM from "react-dom";
import "./app.css";

class App extends React.Component {
  render() {
    return (
      <div className="Container">
        <header className="Header">
          <p>Hello, World!</p>
          <a
            className="Link"
            href="https://reactjs.org/docs/getting-started.html"
          >
            Getting Started
          </a>
        </header>
      </div>
    );
  }
}

ReactDOM.render(<App />, document.getElementById("container"));
